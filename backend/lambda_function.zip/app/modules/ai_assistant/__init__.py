# AI Assistant module
