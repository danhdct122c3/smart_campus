"""Pydantic schemas for the Users module."""

from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, EmailStr, Field


class UserRole(str, Enum):
    ADMIN = "ADMIN"
    DIRECTOR = "DIRECTOR"
    MANAGER = "MANAGER"
    STAFF = "STAFF"
    TECHNICIAN = "TECHNICIAN"


class UserStatus(str, Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    SUSPENDED = "SUSPENDED"


class Department(str, Enum):
    IT = "IT"
    TECHNICAL = "TECHNICAL"
    SECURITY = "SECURITY"
    HR = "HR"
    ADMIN = "ADMIN"



# ── Request models ─────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    email: EmailStr
    name: str = Field(..., min_length=2, max_length=100)
    role: UserRole = UserRole.STAFF
    department: Optional[Department] = None
    phone: Optional[str] = None
    employee_id: Optional[str] = Field(None, description="Mã nhân viên")


class UserUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=100)
    email: Optional[str] = None
    role: Optional[UserRole] = None
    department: Optional[Department] = None
    phone: Optional[str] = None
    status: Optional[UserStatus] = None


# ── Response models ────────────────────────────────────────────────────────────

class UserResponse(BaseModel):
    user_id: str
    email: str
    name: str
    role: UserRole
    department: Optional[Department] = None
    phone: Optional[str] = None
    employee_id: Optional[str] = None
    status: UserStatus
    face_registered: bool = False
    created_at: str
    updated_at: Optional[str] = None


class UserListResponse(BaseModel):
    items: list[UserResponse]
    total: int
    next_key: Optional[str] = None


class UserTaskStatsResponse(BaseModel):
    total_tasks: int
    done: int
    in_progress: int
    overdue: int
    completion_rate: float
