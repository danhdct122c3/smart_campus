"""Business logic for the Notifications module (Workflow 4).

Flow:
    1. EventBridge triggers Lambda with AttendanceRecorded / AttendanceRejected event.
    2. Notification Service xác định loại thông báo cần gửi.
    3. Nội dung được tạo từ template tương ứng.
    4. Thông báo được gửi qua SNS (Email/SMS/Push).
    5. Trạng thái gửi được ghi vào DynamoDB để theo dõi.

Supported channels: EMAIL, SMS, PUSH (via SNS), TEAMS, SLACK, WEBHOOK.
"""

import uuid
from datetime import datetime, timezone

from fastapi import status

from app.core.config import settings
from app.core.exceptions import AppException, ErrorCode
from app.shared.aws import (
    publish_notification_sent,
    publish_to_topic,
    ses,
)
from app.modules.users import repository as user_repo
from .schemas import (
    NotificationChannel,
    NotificationEventType,
    NotificationRecord,
    NotificationStatus,
    SendNotificationRequest,
)
from . import repository as repo


# ── Message templates ──────────────────────────────────────────────────────────

_TEMPLATES: dict[NotificationEventType, dict] = {
    NotificationEventType.WFH_REQUEST_APPROVED: {
        "subject": "[Smart Campus] Yêu cầu nghỉ/WFH của bạn đã được duyệt",
        "message": "Đơn xin {leave_type} từ ngày {date_from} đến {date_to} của bạn đã được phê duyệt thành công.",
    },
    NotificationEventType.WFH_REQUEST_SUBMITTED: {
        "subject": "[Smart Campus] Thông báo",
        "message": "Đơn xin {leave_type} của {requester_name} từ ngày {date_from} đến {date_to} đã được gửi. Ghi chú: {reason}",
    },
    NotificationEventType.ATTENDANCE_RECORDED: {
        "subject": "[Smart Campus] Điểm danh thành công",
        "message": "Bạn đã được ghi nhận điểm danh lúc {timestamp} tại phòng {room_id}. Trạng thái: {status}.",
    },
    NotificationEventType.ATTENDANCE_REJECTED: {
        "subject": "[Smart Campus] Điểm danh bị từ chối",
        "message": "Yêu cầu điểm danh của bạn bị từ chối. Lý do: {reason}.",
    },
    NotificationEventType.UNKNOWN_FACE: {
        "subject": "[Smart Campus] Cảnh báo: Phát hiện khuôn mặt lạ",
        "message": "Hệ thống phát hiện khuôn mặt không xác định tại camera {camera_id} lúc {timestamp}.",
    },
    NotificationEventType.SECURITY_ALERT: {
        "subject": "[Smart Campus] Cảnh báo an ninh",
        "message": "Sự cố an ninh [{risk_level}]: {description}. Vui lòng kiểm tra ngay.",
    },
    NotificationEventType.CUSTOM: {
        "subject": "[Smart Campus] Thông báo",
        "message": "{message}",
    },
    NotificationEventType.TASK_ASSIGNED: {
        "subject": "[Smart Campus] Bạn có công việc mới",
        "message": "Bạn vừa được giao công việc \"{task_title}\" bởi {reporter_name}. Hãy kiểm tra và bắt đầu thực hiện.",
    },
    NotificationEventType.TASK_STATUS_CHANGED: {
        "subject": "[Smart Campus] Cập nhật trạng thái công việc",
        "message": "Công việc \"{task_title}\" đã được cập nhật sang trạng thái: {new_status}.",
    },
    NotificationEventType.TASK_SUBMITTED: {
        "subject": "[Smart Campus] Công việc đã được nộp báo cáo",
        "message": "{assignee_name} đã nộp báo cáo cho công việc \"{task_title}\". Vui lòng kiểm tra và duyệt.",
    },
    NotificationEventType.TASK_COMPLETED: {
        "subject": "[Smart Campus] Công việc đã hoàn thành",
        "message": "Công việc \"{task_title}\" đã được duyệt hoàn thành.",
    },
    NotificationEventType.TASK_UPCOMING_DEADLINE: {
        "subject": "[Smart Campus] ⏳ Cảnh báo: Sắp đến hạn công việc",
        "message": "Công việc \"{task_title}\" do bạn phụ trách sắp hết hạn trong khoảng 10 phút nữa (Hạn chót: {due_date}). Vui lòng nộp báo cáo ngay.",
    },
    NotificationEventType.TASK_OVERDUE: {
        "subject": "[Smart Campus] ⚠️ Cảnh báo: Công việc đã quá hạn",
        "message": "Công việc \"{task_title}\" do bạn phụ trách đã quá hạn thực hiện (Hạn chót: {due_date}). Vui lòng khẩn trương hoàn thành hoặc báo cáo cho {reporter_name}.",
    },
    NotificationEventType.INCIDENT_REPORTED: {
        "subject": "[Smart Campus] Sự cố mới cần xử lý",
        "message": "{reporter_name} vừa báo cáo sự cố \"{task_title}\". Vui lòng kiểm tra và phân công xử lý.",
    },
}


class SafeDict(dict):
    def __missing__(self, key):
        return f"[Chưa có {key}]"

def _build_message(event_type: NotificationEventType, context: dict) -> dict:
    """Fill template with context data securely, handling missing keys."""
    template = _TEMPLATES.get(event_type, _TEMPLATES[NotificationEventType.CUSTOM])
    safe_context = SafeDict(context)
    subject = template["subject"].format_map(safe_context)
    message = template["message"].format_map(safe_context)
    return {"subject": subject, "message": message}


def _persist_and_notify(
    user_id: str,
    channel: NotificationChannel,
    event_type: NotificationEventType,
    subject: str,
    message: str,
    status_val: NotificationStatus = NotificationStatus.SENT,
    error_message: str | None = None,
) -> NotificationRecord:
    """Save record to DynamoDB and publish NotificationSent event."""
    now = datetime.now(timezone.utc).isoformat()
    notification_id = str(uuid.uuid4())

    item = {
        "notification_id": notification_id,
        "user_id": user_id,
        "channel": channel.value,
        "event_type": event_type.value,
        "subject": subject,
        "message": message,
        "status": status_val.value,
        "sent_at": now,
        "error_message": error_message,
    }
    repo.save_notification(item)

    # Publish NotificationSent event (non-critical)
    try:
        if status_val == NotificationStatus.SENT:
            publish_notification_sent(
                notification_id=notification_id,
                user_id=user_id,
                channel=channel.value,
                event_type=event_type.value,
            )
    except Exception:
        pass

    return _to_record(item)


def _deliver_notification(
    user_id: str,
    subject: str,
    message: str,
    skip_ses: bool = False,
) -> tuple[NotificationStatus, str | None]:
    """
    Deliver notification directly to the user via Amazon SES (1-to-1 personal email).
    Only falls back to SNS with filter attributes if SES fails or email not found.
    """
    if not skip_ses:
        try:
            user = user_repo.get_user_by_id(user_id)
            if user and user.get("email"):
                to_email = user["email"]
                user_name = user.get("name") or "Bạn"
                body_html = f"""
                <html>
                <body style="font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px;">
                  <div style="max-width: 560px; margin: auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                    <div style="background: linear-gradient(135deg, #3b82f6, #8b5cf6); padding: 24px; text-align: center;">
                      <h1 style="color: white; margin: 0; font-size: 22px;">🎓 Smart Campus</h1>
                      <p style="color: rgba(255,255,255,0.85); margin: 4px 0 0;">Thông báo từ hệ thống</p>
                    </div>
                    <div style="padding: 32px;">
                      <p style="color: #374151; font-size: 16px;">Xin chào <strong>{user_name}</strong>,</p>
                      <div style="background: #f9fafb; border-left: 4px solid #3b82f6; padding: 16px; margin: 20px 0; color: #111827; font-size: 15px; line-height: 1.5;">
                        {message}
                      </div>
                      <p style="color: #9ca3af; font-size: 13px; margin-top: 24px; border-top: 1px solid #e5e7eb; padding-top: 16px;">
                        Email này được gửi tự động từ hệ thống Smart Campus qua Amazon SES. Vui lòng không trả lời email này.
                      </p>
                    </div>
                  </div>
                </body>
                </html>
                """
                ses.send_email(to_email=to_email, subject=subject, body_html=body_html, body_text=message)
                return NotificationStatus.SENT, None
        except Exception as exc:
            print(f"[SES NOTIF INFO] Could not send SES email to {user_id}: {exc}. Falling back to SNS.")

    # Fallback to SNS with message attributes for filter policy
    try:
        if settings.notification_topic_arn:
            publish_to_topic(
                topic_arn=settings.notification_topic_arn,
                subject=subject,
                message=message,
                message_attributes={
                    "target_user_id": {
                        "DataType": "String",
                        "StringValue": str(user_id),
                    }
                },
            )
        return NotificationStatus.SENT, None
    except Exception as exc:
        return NotificationStatus.FAILED, str(exc)


def send_attendance_notification(
    user_id: str,
    timestamp: str,
    room_id: str,
    attendance_status: str,
    channel: NotificationChannel = NotificationChannel.EMAIL,
) -> NotificationRecord:
    """Called when AttendanceRecorded event is received (WF4 trigger)."""
    content = _build_message(
        NotificationEventType.ATTENDANCE_RECORDED,
        {"timestamp": timestamp, "room_id": room_id, "status": attendance_status},
    )
    # skip_ses=True because attendance/service.py already sends the rich attendance table email via SES
    final_status, error_msg = _deliver_notification(user_id, content["subject"], content["message"], skip_ses=True)

    return _persist_and_notify(
        user_id=user_id,
        channel=channel,
        event_type=NotificationEventType.ATTENDANCE_RECORDED,
        subject=content["subject"],
        message=content["message"],
        status_val=final_status,
        error_message=error_msg,
    )


def send_rejection_notification(
    user_id: str,
    reason: str,
    channel: NotificationChannel = NotificationChannel.EMAIL,
) -> NotificationRecord:
    """Called when AttendanceRejected event is received (WF4 trigger)."""
    content = _build_message(
        NotificationEventType.ATTENDANCE_REJECTED,
        {"reason": reason},
    )
    final_status, error_msg = _deliver_notification(user_id, content["subject"], content["message"], skip_ses=False)

    return _persist_and_notify(
        user_id=user_id,
        channel=channel,
        event_type=NotificationEventType.ATTENDANCE_REJECTED,
        subject=content["subject"],
        message=content["message"],
        status_val=final_status,
        error_message=error_msg,
    )


def send_task_notification(
    user_id: str,
    event_type: NotificationEventType,
    context: dict,
    channel: NotificationChannel = NotificationChannel.PUSH,
) -> NotificationRecord:
    """Send a task-related notification to a user."""
    content = _build_message(event_type, context)
    final_status, error_msg = _deliver_notification(user_id, content["subject"], content["message"], skip_ses=False)

    return _persist_and_notify(
        user_id=user_id,
        channel=channel,
        event_type=event_type,
        subject=content["subject"],
        message=content["message"],
        status_val=final_status,
        error_message=error_msg,
    )


def send_custom_notification(payload: SendNotificationRequest) -> NotificationRecord:
    """REST API: Admin gửi thông báo thủ công."""
    error_msg = None
    final_status = NotificationStatus.SENT
    try:
        if settings.notification_topic_arn:
            publish_to_topic(
                topic_arn=settings.notification_topic_arn,
                subject=payload.subject,
                message=payload.message,
            )
    except Exception as exc:
        error_msg = str(exc)
        final_status = NotificationStatus.FAILED

    return _persist_and_notify(
        user_id=payload.user_id,
        channel=payload.channel,
        event_type=NotificationEventType.CUSTOM,
        subject=payload.subject,
        message=payload.message,
        status_val=final_status,
        error_message=error_msg,
    )


def list_notifications(user_id: str | None, limit: int) -> list[NotificationRecord]:
    if user_id:
        items = repo.list_by_user(user_id, limit=limit)
    else:
        items = repo.list_recent(limit=limit)
    return [_to_record(i) for i in items]


def _to_record(item: dict) -> NotificationRecord:
    return NotificationRecord(
        notification_id=item.get("notification_id", item.get("notificationId", "")),
        user_id=item.get("user_id", item.get("userId", "")),
        channel=item.get("channel", "PUSH"),
        event_type=item.get("event_type", item.get("eventType", "Custom")),
        subject=item.get("subject", ""),
        message=item.get("message", ""),
        status=item.get("status", "SENT"),
        sent_at=item.get("sent_at", item.get("sentAt", "")),
        error_message=item.get("error_message", item.get("errorMessage")),
    )
