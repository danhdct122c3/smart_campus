from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware

from app.api.router import api_router
from app.core.config import settings
from app.core.exceptions import AppException, ErrorCode
from app.core.responses import APIResponse

from aws_xray_sdk.core import xray_recorder, patch_all

# Kích hoạt X-Ray tự động hook vào boto3 và các thư viện hỗ trợ
patch_all()

def create_app() -> FastAPI:
    application = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="Serverless API for Smart Campus Platform"
    )

    # CORS phải được add TRƯỚC khi include_router
    application.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    application.include_router(
        api_router,
        prefix="/api",
    )

    @application.get("/", tags=["Root"])
    def root() -> dict[str, str]:
        return {
            "message": "Welcome to Smart Campus API",
            "docs": "/docs",
        }

    # ── Exception Handlers (tương đương @ControllerAdvice) ────────────────────

    @application.exception_handler(AppException)
    async def app_exception_handler(request: Request, exc: AppException) -> JSONResponse:
        """Xử lý toàn bộ AppException – trả error_code chuẩn cho frontend."""
        return JSONResponse(
            status_code=exc.status_code,
            content=APIResponse.error(
                code=exc.error_code,
                message=exc.message,
            ).model_dump(),
        )

    @application.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        """Pydantic validation error → 422 với format chuẩn thay vì FastAPI default."""
        errors = exc.errors()
        if errors:
            first = errors[0]
            field = str(first["loc"][-1]) if first.get("loc") else "unknown"
            msg = f"Trường '{field}': {first['msg']}"
        else:
            msg = "Dữ liệu đầu vào không hợp lệ."
        return JSONResponse(
            status_code=422,
            content=APIResponse.error(
                code=ErrorCode.VALIDATION_ERROR,
                message=msg,
            ).model_dump(),
        )

    @application.exception_handler(Exception)
    async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
        """Catch-all – tránh lộ stack trace ra ngoài môi trường production."""
        import traceback
        traceback.print_exc()

        try:
            segment = xray_recorder.current_subsegment()
            if segment:
                segment.add_exception(exc, traceback.extract_stack())
                segment.put_http_meta('status', 500)
                segment.fault = True
        except Exception:
            pass

        return JSONResponse(
            status_code=500,
            content=APIResponse.error(
                code=ErrorCode.INTERNAL_ERROR.code,
                message="Đã xảy ra lỗi hệ thống. Vui lòng thử lại sau.",
            ).model_dump(),
        )

    return application

app = create_app()

# Adapter cho AWS Lambda
from mangum import Mangum
from app.modules.tasks.service import check_and_notify_task_deadlines
from app.workers.analytics_worker import handler as analytics_worker_handler
from app.workers.notification_worker import handler as notification_worker_handler

mangum_handler = Mangum(app, lifespan="off")

def handler(event, context):
    # Kiểm tra nếu đây là sự kiện từ SQS
    if "Records" in event and len(event["Records"]) > 0 and event["Records"][0].get("eventSource") == "aws:sqs":
        sqs_arn = event["Records"][0].get("eventSourceARN", "")
        if "analytics-queue" in sqs_arn:
            print("Routing SQS event to Analytics Worker...")
            return analytics_worker_handler(event, context)
        elif "notification-queue" in sqs_arn:
            print("Routing SQS event to Notification Worker...")
            return notification_worker_handler(event, context)
        else:
            print(f"Unknown SQS queue triggered this lambda: {sqs_arn}")
            return {"batchItemFailures": []}

    # Kiểm tra xem đây có phải là sự kiện hẹn giờ từ EventBridge không
    if event.get("source") == "aws.events" or event.get("source") == "smart_campus.scheduler":
        print("Bắt đầu chạy Cronjob kiểm tra task trễ hạn (EventBridge trigger)...")
        check_and_notify_task_deadlines()
        return {"statusCode": 200, "body": "Cronjob completed successfully."}
    
    # Nếu là Web Request bình thường thì giao cho FastAPI xử lý
    return mangum_handler(event, context)